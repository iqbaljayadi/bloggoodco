<?php
/*
Template Name: List Fusion Squeeze Page
*/



$listfusion_squeezepage           = get_post_meta($post->ID, 'listfusion_squeezepage');
$listfusion_szpg_seo_title        = get_post_meta($post->ID, 'listfusion_szpg_seo_title');
$listfusion_szpg_seo_meta_dec     = get_post_meta($post->ID, 'listfusion_szpg_seo_meta_dec');
$listfusion_szpg_seo_meta_key     = get_post_meta($post->ID, 'listfusion_szpg_seo_meta_key');
$listfusion_szpg_seo_noindex      = get_post_meta($post->ID, 'listfusion_szpg_seo_noindex');
$listfusion_szpg_seo_nofollow     = get_post_meta($post->ID, 'listfusion_szpg_seo_nofollow');
$listfusion_szpg_seo_noarchive    = get_post_meta($post->ID, 'listfusion_szpg_seo_noarchive');
$listfusion_szpg_seo_footer_code  = get_post_meta($post->ID, 'listfusion_szpg_seo_footer_code');


if(function_exists('listfusion_display_sqeezePg')) listfusion_display_sqeezePg($listfusion_squeezepage[0],  
																	$listfusion_szpg_seo_title[0], 
																	$listfusion_szpg_seo_meta_dec[0],  
																	$listfusion_szpg_seo_meta_key[0],       
																	$listfusion_szpg_seo_noindex[0],  
																	$listfusion_szpg_seo_nofollow[0],    
																	$listfusion_szpg_seo_noarchive[0],     
																	$listfusion_szpg_seo_footer_code[0]
														  );
?>